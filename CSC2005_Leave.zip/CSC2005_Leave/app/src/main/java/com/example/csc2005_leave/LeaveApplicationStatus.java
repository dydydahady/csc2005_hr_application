package com.example.csc2005_leave;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class LeaveApplicationStatus extends AppCompatActivity {
    TextView receiver_LeaveType;
    TextView receiver_FromDate;
    TextView receiver_ToDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_application_status);

        receiver_LeaveType = (TextView)findViewById(R.id.LeaveType);
        receiver_FromDate = (TextView)findViewById(R.id.FromDate);
        receiver_ToDate = (TextView)findViewById(R.id.ToDate);

        // create the get Intent object
        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first activity
        String LeaveType = intent.getStringExtra("LeaveType_key");
        String FromDate = intent.getStringExtra("FromDate_key");
        String ToDate = intent.getStringExtra("ToDate_key");

        // display the string into textView

        receiver_LeaveType.setText(LeaveType);
        receiver_FromDate.setText(FromDate);
        receiver_LeaveType.setText(ToDate);
        System.out.println("Does this work?");
    }
}