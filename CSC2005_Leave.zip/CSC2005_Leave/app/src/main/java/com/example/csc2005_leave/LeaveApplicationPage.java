package com.example.csc2005_leave;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class LeaveApplicationPage extends AppCompatActivity {


    Spinner spinner1;


    DatePickerDialog datePickerDialog;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;
    AlertDialog.Builder builder;
    Object item;




        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_application_page);
        Button selectDateFrom = findViewById(R.id.btnDateFrom);
        TextView dateFrom = findViewById(R.id.FromDate);


        Spinner spinner = findViewById(R.id.spinner1);


        Button selectDateTo = findViewById(R.id.btnDateTo);
        TextView dateTo = findViewById(R.id.ToDate);

        Button submitBtn = findViewById(R.id.SubmitBtn);
        builder = new AlertDialog.Builder(this);

            spinner.setOnItemSelectedListener(
                    new AdapterView.OnItemSelectedListener() {
                        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                            item = parent.getItemAtPosition(pos);
                            System.out.println(item.toString());     //prints the text in spinner item.

                        }
                        public void onNothingSelected(AdapterView<?> parent) {
                        }
                    });

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                builder.setMessage("Do you want to submit Leave Application?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //String LeaveType = spinner1.getSelectedItem().toString();
                                String LeaveType = item.toString();
                                String FromDate = dateFrom.toString();
                                String ToDate = dateTo.toString();
                                Intent intent = new Intent(getApplicationContext(), LeaveApplicationStatus.class);

                                intent.putExtra("FromDate_key", FromDate);
                                intent.putExtra("ToDate_key", ToDate);
                                intent.putExtra("LeaveType_key", LeaveType);
                                //finish();
                                Toast.makeText(getApplicationContext(),"Leave Applied",
                                        Toast.LENGTH_SHORT).show();

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                                Toast.makeText(getApplicationContext(),"Cancelled",
                                        Toast.LENGTH_SHORT).show();


                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("Leave Application Submission");
                alert.show();

            }
        });










        selectDateFrom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(LeaveApplicationPage.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                dateFrom.setText(day + "/" + (month + 1) + "/" + year);
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }


        });

        selectDateTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(LeaveApplicationPage.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                dateTo.setText(day + "/" + (month + 1) + "/" + year);
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });


    }
}









