package com.example.csc2005_leave;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LeaveInfoPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_info_page);
    }
}