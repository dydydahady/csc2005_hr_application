package com.example.csc2005_team04.ui.claims;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.csc2005_team04.R;


public class ClaimApplicationDone extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claim_application_done);


        };

}